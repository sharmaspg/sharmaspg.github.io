# Mountain is you

This is a book about How we are coming in our own way when we are trying to accomplish something. Self sabotaging our goals in order to not move out of something that is familiar and comfortable. 

![The-Mountain-Is-You-Transforming-Self-Sabotage-Into-Self-Mastery-1200x900.jpg](f3d4c17a-ce10-46d9-a7ee-c56f52a6fb63.png)

## Introduction

Self sabotage is a coping mechanism in order to temporarily relive ourself from our deepest desires and fears.

As everything in nature, you need to go through regular cycle of breaking and rebuilding your image, your belief system and your assumptions in order to align with the present situation.

Mountain is metaphorically used here in order to say that there is a obstacle in your life, an obstacle that if examined correctly will transform your life. and if left unaddressed will waste your potential. 

> “Your mountain is the block between you and the life you want to live. Facing it is also the only path to your freedom and becoming. You are here because a trigger showed you to your wound, and your wound will show you to your path, and your path will show you to your destiny.”
> 

## Chapter 1 - Mountain is you

If there is a gap between where you are and who you want to be and this gap seems to be not closing then self sabotage is always at work. 

> Self Sabotage is simply the presence of an unconscious need that is being fulfilled by the self sabotaging behavior. To overcome this, we must go through a process of deep psychological excavation. pinpoint the traumatic event, release unprocessed emotions , find healthier ways of meeting our needs, reinvent our self image and develop principles such as emotional intelligence and resilience.
> 

### Self Sabotage is not always Obvious at the onset -

Example - If you always wanted to be the driver and feel every uncomfortable when someone else drives, you might have a fear of losing control, you need to understand why you are that fear, what events led you into believe that you need to have control on everything. 

### Self Sabotage is an Irrational Fear -

If you always deny for a portrait or an image - you might have a perceptions that you are unattractive , disliked. 

Example your fears thoroughly , try to understand why you have this fear, what events led you to believe in them , what is the action plan on changing that fear. 

### Self Sabotage comes from unconscious , negative associations - self image

first signs that your inner narrative is outdated is when you are self sabotaging some goals. 

If you really want to loose weight but still end up binging on junk food, you need to address whats soothing you or making you to eat junk. You might have an image of yourself where you are not healthy and who is always a junk eater. Maybe  eating junk and partying made you look and you always wanted to look cool, you have created a negative association here.

Your image is built on day to day events and other’s opinion of yourself. You can change it by consciously thinking about it.

### Self Sabotage comes from what unfamiliar

Humans experience a natural resistance to the unknown. because it is the ultimate loss of control. This is true even if what’s “unknown” is benevolent or event beneficial to you.

you need to become familiar with the change then it comes less intimidating. 

Even if things are going really good, you will try to screw it up because every human has an upper limit on happiness tolerance, above which is unfamiliar territory and you do not want to go to that phase naturally. 

### Self sabotage comes from our belief systems

There is always an inner narative going on in your head about who you are, what is right for you, whats good for you. You need to examine these belief systems regularly , because these belief system becomes your identity 

example - if you keep thinking that you are an anxious person, over time you will become that person. you believe that suffering is a virtual of kindness, this is also one of the false belief. 

To truly heal you are going to have to change the way you think , you need to question and change the belief system in yourself. 

### How to get out of Denial

Stop trying to cope with behaviors that are not serving your purpose of living authentically. 

Get real with your self. See the behavior for what it is. 

If you have ever tried to “love ourselves” and it has not worked out in the long run, its mostly because deep down , we know we are not quite being who we really want to be, and until you accept that you will never have peace and your self healing journey will never start. 

 Take full responsibility of your life, where you are now is the result of no body else other than yourself. 

> The greated act of self-love is to no longer accept a life you are unhappy with. It is to be able to state the problem plainly and in a straightforware manner.
> 

Excercise - Take a piece of paper and pen and write down everything you are unhappy about in your life. 

**Once you have the list , make peace or commit to changing it , lingering is what keeps you stuck.**

### The path begins right where you are now

Start where you are , broke, alone, in pain. 

Starting point does not matter 

We must change, we must heal , we must find and use tools that will help us lead a truly meaning full and authenticate life.

This thought is not an idea, its a declaration and a resolution - “I never want to feel this way again”

> Human beings are guided by comfort. They stay close to what feels familiar and reject what doesn't , even if its objectively better for them. most people will not change until not changing is unbearable, they will embrace the difficulty of altering their habits until they simply do not have another choice.
> 

 
If you really want to change your life. Let yourself be consumed by rage - 
Get angry , determined and develop tunnel vision with one thing - “ I will not go on like this”

### Prepare for Radical Change

Biggest fear of self examination and healing is changing your life drastically. 
You will loose many things in this process - 

1. yourself
2. friends and families 
3. habits
4. comfort zone

Your new life will cost you the old life.  you need to embrace the discomfort and be willing to go extra mile even if people leave. 

what you are loosing is a loss to your older self. 

your new self will aquire far better things than the past you, so no worries. 

---

## Chapter 2 - There is no such thing as a self sabotage

Self sabotage looks like some toxic trait in your personality  that you feel like you are compiled to remove from your life, but it is a behavior that is serving a purpose , it is protecting you from a belief system conflict or some other inner conflict. 

> Overcoming self sabotage is not about trying to figure out how to override your impulses, it is first determining why those impulses exist in the first place
> 

the reason why we are self sabotaging is because we are afraid of something 

for example - Getting too wealthy makes us corrupt and selfish, being in a relationship makes us vulnerable, being famous will put you in scrutiny and judgement of others etc

### What does self sabotage looks like

There is no one fit for all , but there are some patterns - 

Resistance - Do you hesitate or voluntarily miss out on what needs to be done to achieve your goal ? you might be used to being on survival and thriving feels like a uncharted territory and you will destroy the progress in order to struggle again - 

How to resolve - Self examine why there is resistance, what belief system is stopping you, , regroup and refocus

Hitting your upper limit 

Uprooting

Perfectionism

Limited Emotional processing skills

Justification

Disorganization

Attachment to what you dont really want

Judging others

Pride

Guilt of succeeding

Fear of failing 

Downplaying

Unhealthy Habits

Being “Busy”

Spending time with wrong people

Worrying about irrational fears

### How to tell if you are in a self sabotage cycle

1. you are more aware of what you dont want than what you want
2. you spend more time trying to impress people who dont like you than you spend with people who love you for who you are.
3. you are putting your head in the sand - not in touch with basic facts 
4. you care more about convincing other people you are okay than actually being okay 
5. your main priority in life is to be liked, even if that comes at the expense of being happy
6. you are more afraid of your feeling than anything else
7. you are blindly chasing goals without asking yourself why 
8. you are treatign your coping mechanism as the problem
9. you value your doubt more than tour potential 
10. you are trying to care about everything 
11. you dont realise how far you have come

### Identify your subconscious commitments

The less that you feed your core need, the “louder” your core commitment symptoms will be

People only seem irrational because you don't know what they are committed to. Once you figure that out , it will become very clear.

Confront repressed emotions and move towards healing 

You will face resistance in the beginning , it's natural , anything that is unfamiliar will be fought with almost resistance.

Disconnect feeling from action 

You are not doing the things you want to do because you are not feeling it

 

Feeling is a comfort system , you will feel relaxed only when you are doing things that are familiar 

Take actions. Build momentum , momentum builds motivation , motivation evokes the feeling

---

## Chapter 3 - Your triggers are the guides to your freedom

if you can observe your self sabotaging behaviours it will give deeper insights into what you need, who you are. It will help you better understand yourself personally. 

This behaviour is nothing but a coping mechanism for a deeper need - 
example -  Anger , deep disagreement regarding something that will not sit correctly with you. 

### How to Interpret Negative Emotions -

1. Anger - 
    1. Instead of being afraid of anger , we can insttead use it to help us see our limits and priorities more clearly. 
2. sadness -
    1. Sadness only becomes problematic when we do not allow ourselves to go through phases of grief. when we do not allow ourself to feel those emotions. when there is embarassement and shame around feeling sad and crying
3. Guilt - 
    1. when we didnt do that what we did
    2. Guilt in itself shows that you are a good person. 
    3. if its generally guilt feeling then we need to take a close look at who or what made us always feel as though we were wrong or inconvenienving others.  Its almost an emotion that we carry from our childhood
4. Embarrassment -
    1. we did not behave in a way that we are proud of. Other people can never make us feel as embarassed than we do
5.  Jealousy - 
    1. Something in some other person which we deeply desire
6. Resentment  - 
    1. Its like projected regret, 
    2. Not seeing people or things for what they are , instead projecting our expectations and imaginations on to things and seeing them fail 
7. Regret -
    1. Regret is a good thing and everyone has this. 
    2. this feeling will teach what is important what you need to do in future in order to avoid this feeling
    3. Didnt travel when you were young ? regret is showing you that you should do it now. 
    4. Didnt love someone while you had them ? regreset is showing you to value people now.
8. Chronic fear - 
    1. It is a way of thinking wrost possible outcomes and trying to numb yourself with it
    2. It will give you a sense of flow - oh if i keep thinking about these things then for sure it will not be a surpise if it happens and my efforts in thinking will be justified.
    3. Go with this attitude - “Fuck it , if it happens , it happens”

### Our Internal Guidance system whisper until they scream

These emotions are whispering the subconcious needs that are partially or never met as an adult. 

Your need to feel financially secure is healthy , it is not always a product of you being greedy.

Your need to be validated for the work that you do is healthy and it is not always a product of you being in vain. Your need to live in a space that youu enjoy is healthy and it is not a product of you being un greatful.

### Your subconcious mind is trying to communicate with you -

1. The way you are sabotaging - 
    1. Going back to the person who broke you - ( evaluate your childhood relationships , if you find something comforting about someone who is hurting you  )
    2. Attracting people who are too broken to commit - (  you are not too broken to find someone who actually wants you and when you begin to recognize that you are worthy , you will start choosing right partner )
    3. Feeling unhappy even if nothing is wrong - (  you might be expecting outside things to make you feel good, No inner peace and content ) 
    4. Pushing people away -  ( you want people to like you soo much that it is creating pressure in your head and you this stress makes you isolate people ) 
    5. Automatically thinking what you think and feel is true - Feeling and thoughts are sporatic things and they should not be taken at face value.  you will be at the whim of your emotions and always riding a roller coaster. 
    6. Eating poorly - you are doing too much. without rest and nuritment 
    7. Having defeating thoughts - ( if you are your biggest critic , nobodies comments will affect you that much )

### Listen to your quiet whispering Gut feelings

> If you want to master your life, you have to learn to organise your feelings. By becoming aware of them, you can trace them back to the thought process that prompted them , and from there you can decide whether or not the idea is an actual threat or concern or a fabrication of your reptilian mind just trying to keep you alive.
> 

### How to start truly meeting your needs

Basic needs - nourishment , sleep , movement , dress appropriately and allow yourself to feel what you feel without judgement and suppression is the foundations 

Understanding and accepting your needs , meeting the ones you are responsible for, and then allowing yourself to show up so others can meet yhe ones you cant do on your own will help you break the self - sabotage cycle and build a healthier more balanced and fulfilling life. 

---

## Chapter 4 - Building Emotional Intelligence

Emotional Intelligence is the ability to understand, interpret and respond to your emotions in a healthy way. 

### Your brain is designed to resist what you really want

Achieving your goals creates a vacuum where you will be pushed to create new goals and pursue them. You might not be up for that challenge subconsciously  

When we get it, we fear losing it so badly that we push it away from ourselves so as to not have it withstand the pain. 

you need to move from surving mode to thriving mode 

### You are governed by homeostatic impulses

your body is governed by  your brain . this homeostatic impulses regulate your day to day activities.

which means when are doing a chance, we need to let our body adjust to these changes, and make this the new normalcy 

### You don’t need to make a big change, you should make micro shifts

you are waiting for a big overnight change, like you wake up for a big different person , this almost always never work. 
You need to make small micro changes, your body needs to adjust to new normalcy . 
Resist to look at your phone more than yesterday. workout 5 mins more today etc. 

### Your mind is AntiFragile

Our mind is be nature looking for dangers, like almost seeking problems. 

Humans are naturally antifragile, which means it requires adversity to become better.  If you deny and reject any kind of real challenge in your life, your brain will compensat by creating a problem to overcome.  except this time, there wont be any reward at the end. 

Focus on real problems in the work like hunger or politics. embrace the grit of it all. 

### New Change creates adjustment shock

Anything that deviates from normal routine will create a friction , shock in mind, hence you need to slowing implement the new behaviour. 

### What are the Adjustment shock symptoms

heighten vigilance, anxiety or irritability

> We often resist most deeply the things that we want most
> 

### psychic thinking isnt wisdom

psychic thinking is nothing more than a series of cognitive biases, the most prominent of which arew

Confirmation -  Our brain are literally working to filter our information that does not support our preexisting idea, confirmation bias/.

Extrapolation  - when we rake our current circumstances and then project them out into the future.  which means we think that we are the sums of our past or current experiences, that whatever stressors or anxieties we are currently experiencing are ones that we will grapple with for the rest of our lifes. 

Spotlighting - 

Everyone thinks that the world revolves around them , you are thinking about you and your own interests , so is everyone. 

### Logical lapses are giving you profound anxiety

Most of the anxiety is because of insufficient critical thinking.  People think anxiety is because of overthinking but its because of under thinking , you are just going through pre programmed sequence of thoughts without critical thinking. 

### Faulty Inferences are holding you back from success

highly intelligent people will be quick in inferning something and group experiences into buckets. 

these experiences will not be questions that that might lead to stuck feeling or wrong Inference that will not help you with your life. 

Example - hasty generalization , when a boss calls assuming that you are either getting a raise or being fired. 

what you consistently do is what you adopt to , being aware of your inferences is the first step in stopping. 

### Worrying is the weakest defence system

If we imagine our worst fears , we can prepare for them , if we mull them over again and again , we can feel protected in a way . Worrying senstizies us to an infinity of negative possible outcomes. It shifts our mindset to expect, seek out and create a worst-case scenario. If we keep worrying about somethign and that does not happen ( because it was totally fictional )  then we will associate it with safety. 

You dont need to constantly be worrying about the next big thing ,  learn to move into a new pattern of thinking in which you recognize that you dont need to balance out the bad with the good to live a full and faire life. 

Worrying fulfills a deep need within us to feel as though we have conquered and thus  are protected and saved. 

Theres a better way of feeding your emotional hunger and its not fighting yourself for your own inner peace. 

---

## Chapter 5  - releasing the past

Over the course of our life, many times we are going to redefine ourselves. physically, mentally and emotionally we are going to hit that reset button often. 
But when we resist to feel certain emotions because it was un bearable at the point , we will accumulate traumas , baggages and debris . we need to release that past trauma  , emotion by going back to that moment as a healed indivisual and feel those emotions

### How to Start Letting Go

it is hard to let go of something that you so hardly cling on to. Sometimes those things will become a part of your identity. So dont let it go , Start to lead a new life, define yourself in a new way that is not defined from that trauma , slowly those emotions will loose its grip and eventually it will fade. This is how you need to let things go  because  the more you pressure yourself to move away , the more you will grip those emotions . 

Allow yourself to feel sad, cry and let all those emotions roll over your and in the aftermath you will be so profound , so stunned , you will realize that maybe the loss was part of the plan. Maybe it awakened a part of you that would have remained dormant had you not been pushed the way you were. 

### The Psyhologival trick to release old experiences

Some experiences will leave us devistated , breakups , loosing someone we love. we mentally become trapped in these places from which we still crave an experience. 
What we dont realize is that we have to sort of free ourselves from it so that we can go forth and create it in real time. 

We have to be able to see what was at the core of our desire and figure out a way to still give ourselves that experience now.

If you truly want to let go of a past experience, you have to reenter it through your memory . Console your younger self and impart wisdom as a older , matured indivisual 

this is the thing , you experience something that is so life-shifting, mind-altering and deeply traumatic, then find that society only has a small bandwidht for tolerating your fear. you buckle this feeling internally and move on with your life on the surface level. You need to go back and completely face those emotions.
You need to revisit those emotions until it doesnt affect you anymore. 

### Letting Go of Unrealistic Expectations

It is not brave to say you love your body only after you have contorted it to precisely what you want it to look like, say you dont care abour possessions when you have access to everything in the world. 

Truth is that you do not change your life when you fix every piece and call that healing . 
 **” You change your life when you start showing up exactly as you are “**

### What Leaves the path is clearing the path

What is not yours will never come to you , what is yours will never leave you. 

### Recovering from emotional trauma

Trauma is in your body, take a couple of breaths and identify that stuck feeling in  your body , 
it might be in heart, neck , shoulders. Look into that pain,traumas might be lurking there . 
example - you might store anxiety in your shoulders  ( “weight on my shoulders”) 

Neurologically , we process stress in 3 parts - amygdala(center of rumination), hippocampus (center of emotion and memory)and prefrontal cortex( planning and self development)

PTSD patients have bigger amygdala and decresed hippocampus and prefrontal cortex.

### Release emotional backlogs

Like clogged up mailing systems, our emotional baggages gets clogged by past emotions not felt. Go through those emotions from time to time.  Do not put off the feeling

Start meditating to feel and not just to stay calm 

### Use Breath scans to find residual tension in the body

sweat, move and cry

Fear is not going to protect you  action is. Worrying is not going to protect you preparing is . 
Overthinking is not going to protect you . Understanding is. 

Healing - its about getting to a place where you priortize nothing over the quality of your one, short life. 

### Moving forward isn’t about getting revenge.

your glow up might not be something others can see. It migth not come across as a shift on the surface. 

A real glow up is authentic. It is lifting off all the cover up bullshit and addressing the real problems. It is healing . It is changing for good. It is for the first time priortizing your heart over anything else. 

your glow up concerns only you, nobody is looking up to you, they are busy in there over world. 

This growth, glow up , this change is yours , your personal journey where you are disproving yourself. your older self. 

---

## Chapter 6 - Building a New Future

When you are releasing your past, it will generate a vaccum , you need to be building a better future in order to take that place. 

### Meeting your higher potential self

The process is to imagine the most highest best version of yourself and reverse engineer your day to day activities to mimic that person. 

It is also doing something called inner child work, meeting or imagining you meet your younger self , nuture guide them 

These are the visualization technique - 

1. Face your fears first  - Ask your higher self to come sit with you
2. Notice how that higher self is , his physical body, his demeanor, his calmness
3. Ask for guidance 
4. Imagine them handing you the “Keys” to that life - your new improved life

### Release your fears/traumas into the quantum field

traumas will be stored in your body , feel those emotions and let them go 

1. Identify what caused the trauma 
2. resonate a sense of safety 
3. stop taking thoughts and feelings at face value 

### Become the most powerful version of yourself

Ask yourself what would my most powerful person do in this perticular situation 

Be Aware of your weaknesses and work on them 

Be willing to be disliked 

Act on purpose 

Do inner child work 

### Learn to validate your feelings

Understand that whatever your emotions / feelings are , its a valid feeling at that point . do not try to judge or push them away. Learn what it is teaching , its an opportunity to learn more about ourself. 

Think of these feelings like a water flowing , you should not close the tap . let them water flow 

### Adopting your own principles

A principle is a foundational truth upon which you can build your life. They are personal guidelines 

examples for financial principles - keep your debts low, live below your means 

Any natural system required principles , you cannot cram it when there is an emergency 

example - you can cram when exams are near by but you cannot do that as a farmer. you need to have good principles on sowing the seeds before rainy season and have the principle of nuturing the crops with pesticides and watering and only then you can see a good yield. 
same goes for your life. 

Begin with these -

1. What do you value ? What do you genuinely care about ?
2. what feeling do you want to experience in life ?
3. what makes your uneasy or gives axiety?

### Finding your true purpose

Finding true purpose is being present at the moment and a slow beacon on what you need and what you are willing to spend time, energy and money on. 

Its the point where your skills ,interest and the market intersects

These questions will help in figuring out your purpose - 

1. what and who is worth suffering for ?
2. close your eyes and imagine the best version of yourself ,what is that person like ?
3.  If social media didn’t exist, what would you do with your life ?
4. What comes naturally to you ?
5. what would your daily routine look like?
6. what do you want your legacy to be ?

---

## Chapter 7 From Self Sabotage to Self Mastery

Once you are able to recognize and understand your self sabotaging behaviors , natural progression is for self mastery. 

### Controlling your emotions vs suppressing them

you should be able to understand your emotions and figure out how to react to those emotions that is control . 

1. How do you know if you are suppressing or controlling your emotions?
2. suppressing is unconscious , controlling is conscious.

### Learning to trust yourself

Trust that everything will be alright, in the end everything will be good and if its not good , its not the end. 

you know “deep down” that something will workout later. There is an  equilibrium to which you need to get back from the turmoil of the emotions  

### Create aligned goals

Do not chase happiness, happiness is fickle and shallow. build goals around purpose , meaning 

and effort. 

### Find your inner peace

1. what drives us away from our inner peace in the first place ?
    1. When we trust our feelings for its face value , we will get into a vicious cycle where feelings create thoughts , thoughts reinforce the feeling and those thoughts and feelings are not questioned properly 
2. Why cant people find inner peace?
    1. everyone needs to do inner child work. 
3. How to find inner peace ?
    1. Everything you have intensely worried about in your life. 
    2. Every difficult situation you swore you would never get through or never get out
    3. Everytime you have felt happy and at peace.

### Detach from worrying

Worrying reinforces a sense of false safety. which can turn into a cycle and reinforce more worry. 

### Remembering that your feelings are not always facts

### becoming mentally strong

mental strength is a process and its a practice - 

1. Get a plan , because plans fix problems 
2. humble yourself , its not all about you. 
3. Ask for help 
4. know what you dont know, and stop false dichotomous thinking - ex - if i  lose my job, i am a failure. 
5. Stop trying to be psychic ,because  this is cognitive distortion
6. Take responsibility for your outcomes - all of them 
7. Learn how to feel better by processing complex emotions 
8. forget what happened and focus on how you will make it right 
9. Talk it out , because things are often more complicated in your head. 
10. take your time, because you dont need to figure everything out right now 
11. take triggers as a signal 
12. Honor your discomfort, because  its trying to tell you somethign 

### How to truly enjoy your life

1. Be present at the moment and feel evey emotions if not at that moment , acknowledge and vent it later. 
2. stop trying to be happy 
3. arrive into the present 
4. Stop trying to assert dominance
5. lean into the little joys when you find them 
6. nuture positive relationships when you have them
7. learn something new as often as you can 
8. see challenging times as opportunities for transformation
9. be aware of what you give your energy to 
10. schedule time to do nothing 
11. schedule time to play

### Becoming a master of yourself

in the end of your life, you will begin to see that your mountains are really gifts 

they were the pivotal points for your personal growth 

> It is not what happens , but the way one responds , that determines the outcome.
> 

one day the mountain that was in front of tou will be far behind you. It will barely be visible in the distance . 
But what you become in learning to climb it? that will stay with you forever.

---